﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Factorial_Number
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        { //Set integer equal to text box
            int input = Int32.Parse(factorialTextbox.Text);
            int answer = 1;
            // Create a while loop that returns sums of factorials
            while (input > 1)
            {
                answer = answer * input;
                input--;
            }
            displayLabel.Text = answer + "";
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //close the program
            this.Close();
        }
    }
}
