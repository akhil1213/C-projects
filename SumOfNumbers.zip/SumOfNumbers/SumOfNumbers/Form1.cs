﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SumOfNumbers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            string[] nums = input.Split(',');
            int sum = 0;
            foreach ( string num in nums)
            {
                sum = sum + Int32.Parse(num);
            }
            label1.Text = sum + "";
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //Close the program
            this.Close();
        }
    }
}
