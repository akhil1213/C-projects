﻿using System;

public class Person
{
    string personName, emailAddress, telephone;
	public Person(string p, string e, string t)
	{
        personName = p;
        emailAddress = e;
        telephone = t;
	}
    public void setName(string p)
    {
        personName = p;
    }
}
