﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dorm_and_Meal_Plan_Calculator_1
{
    public partial class CaculationForm : Form
    {
        public CaculationForm(string x)
        {
            InitializeComponent();
            displayLabel.Text = x;
        }

        private void DisplayLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
