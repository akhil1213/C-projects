﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dorm_and_Meal_Plan_Calculator_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            int price = 0;
            bool oneCheckBox = true;
            if (unlimitedCheckBox.Checked == true && meal7CheckBox.Checked !=true && meal14CheckBox.Checked !=true)
            {
                price += 1700;
            }else if(meal7CheckBox.Checked && unlimitedCheckBox.Checked !=true && meal14CheckBox.Checked!=true){
                price += 600;
            }
            else if( meal14CheckBox.Checked && meal7CheckBox.Checked !=true && unlimitedCheckBox.Checked != true)
            {
                price += 1200;
            }
            else
            {
                price = 0;
                oneCheckBox = false;
            }
      
            if(allenHallCheckBox.Checked == true && !pikeHallCheckBox.Checked && !farthingHallCheckBox.Checked && !checkBox1.Checked)
            {
                price += 1500;
            }else if(allenHallCheckBox.Checked != true && pikeHallCheckBox.Checked && !farthingHallCheckBox.Checked && !checkBox1.Checked)
            {
                price += 1600;
            }else if(allenHallCheckBox.Checked != true && !pikeHallCheckBox.Checked && farthingHallCheckBox.Checked && !checkBox1.Checked)
            {
                price += 1800;
            }
            else if (allenHallCheckBox.Checked != true && !pikeHallCheckBox.Checked && !farthingHallCheckBox.Checked && checkBox1.Checked)
            {
                price += 2500;
            }
            else
            {
                price = 0;
                oneCheckBox = false;
            }
            
            if (price != 0 && oneCheckBox)
            {
                CaculationForm C = new CaculationForm(price + "");
                C.ShowDialog();
            }
            else
            {
                CaculationForm C = new CaculationForm("Only Pick 1 Choice");
                C.ShowDialog();
            }

        }

        private void UnlimitedCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
