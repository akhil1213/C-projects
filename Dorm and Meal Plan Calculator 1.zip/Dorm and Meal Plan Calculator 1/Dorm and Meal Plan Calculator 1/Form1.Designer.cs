﻿namespace Dorm_and_Meal_Plan_Calculator_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.allenHallCheckBox = new System.Windows.Forms.CheckBox();
            this.pikeHallCheckBox = new System.Windows.Forms.CheckBox();
            this.farthingHallCheckBox = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.meal7CheckBox = new System.Windows.Forms.CheckBox();
            this.meal14CheckBox = new System.Windows.Forms.CheckBox();
            this.unlimitedCheckBox = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // allenHallCheckBox
            // 
            this.allenHallCheckBox.Location = new System.Drawing.Point(94, 161);
            this.allenHallCheckBox.Name = "allenHallCheckBox";
            this.allenHallCheckBox.Size = new System.Drawing.Size(200, 31);
            this.allenHallCheckBox.TabIndex = 0;
            this.allenHallCheckBox.Text = "Allen Hall";
            this.allenHallCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.allenHallCheckBox.UseVisualStyleBackColor = true;
            // 
            // pikeHallCheckBox
            // 
            this.pikeHallCheckBox.Location = new System.Drawing.Point(94, 219);
            this.pikeHallCheckBox.Name = "pikeHallCheckBox";
            this.pikeHallCheckBox.Size = new System.Drawing.Size(200, 31);
            this.pikeHallCheckBox.TabIndex = 1;
            this.pikeHallCheckBox.Text = "Pike Hall";
            this.pikeHallCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pikeHallCheckBox.UseVisualStyleBackColor = true;
            // 
            // farthingHallCheckBox
            // 
            this.farthingHallCheckBox.Location = new System.Drawing.Point(94, 279);
            this.farthingHallCheckBox.Name = "farthingHallCheckBox";
            this.farthingHallCheckBox.Size = new System.Drawing.Size(200, 31);
            this.farthingHallCheckBox.TabIndex = 2;
            this.farthingHallCheckBox.Text = "Farthing Hall";
            this.farthingHallCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.farthingHallCheckBox.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.Location = new System.Drawing.Point(94, 328);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(250, 31);
            this.checkBox1.TabIndex = 3;
            this.checkBox1.Text = "University Suites";
            this.checkBox1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // meal7CheckBox
            // 
            this.meal7CheckBox.Location = new System.Drawing.Point(403, 172);
            this.meal7CheckBox.Name = "meal7CheckBox";
            this.meal7CheckBox.Size = new System.Drawing.Size(265, 31);
            this.meal7CheckBox.TabIndex = 4;
            this.meal7CheckBox.Text = "7 meals per week";
            this.meal7CheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.meal7CheckBox.UseVisualStyleBackColor = true;
            // 
            // meal14CheckBox
            // 
            this.meal14CheckBox.Location = new System.Drawing.Point(403, 237);
            this.meal14CheckBox.Name = "meal14CheckBox";
            this.meal14CheckBox.Size = new System.Drawing.Size(265, 31);
            this.meal14CheckBox.TabIndex = 5;
            this.meal14CheckBox.Text = "14 meals per week";
            this.meal14CheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.meal14CheckBox.UseVisualStyleBackColor = true;
            // 
            // unlimitedCheckBox
            // 
            this.unlimitedCheckBox.Location = new System.Drawing.Point(403, 302);
            this.unlimitedCheckBox.Name = "unlimitedCheckBox";
            this.unlimitedCheckBox.Size = new System.Drawing.Size(265, 31);
            this.unlimitedCheckBox.TabIndex = 6;
            this.unlimitedCheckBox.Text = "Unlimited ";
            this.unlimitedCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.unlimitedCheckBox.UseVisualStyleBackColor = true;
            this.unlimitedCheckBox.CheckedChanged += new System.EventHandler(this.UnlimitedCheckBox_CheckedChanged);
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(89, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(574, 64);
            this.label1.TabIndex = 7;
            this.label1.Text = "Choose one dorm and one meal plan below to calculate the total expenses of dorm a" +
    "nd meal plan per semester ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(170, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 25);
            this.label2.TabIndex = 8;
            this.label2.Text = "Dorms:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(490, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 25);
            this.label3.TabIndex = 9;
            this.label3.Text = "Meal Plan:";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(283, 397);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(197, 40);
            this.calculateButton.TabIndex = 10;
            this.calculateButton.Text = "Calculate ";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 480);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.unlimitedCheckBox);
            this.Controls.Add(this.meal14CheckBox);
            this.Controls.Add(this.meal7CheckBox);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.farthingHallCheckBox);
            this.Controls.Add(this.pikeHallCheckBox);
            this.Controls.Add(this.allenHallCheckBox);
            this.Name = "Form1";
            this.Text = "Dorm and Meal Plan Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox allenHallCheckBox;
        private System.Windows.Forms.CheckBox pikeHallCheckBox;
        private System.Windows.Forms.CheckBox farthingHallCheckBox;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox meal7CheckBox;
        private System.Windows.Forms.CheckBox meal14CheckBox;
        private System.Windows.Forms.CheckBox unlimitedCheckBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button calculateButton;
    }
}

