﻿using System;

public class Customer
{
    private string customer;
    private Boolean mailList;
    private string message = "You will get mail";
	public Customer(string c, Boolean m) 
	{
        customer = c;
        mailList = m;
	}
    public string message()
    {
        return message;
    }
    
}
