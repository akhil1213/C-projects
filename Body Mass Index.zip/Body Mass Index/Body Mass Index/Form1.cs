﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Body_Mass_Index
{
    public partial class form1 : Form
    {
        public form1()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            double weight; // To hold the weight of the person 
            double height; // To hold the height of the  person
            double BMI; // Calculate BMI

            //Get height used and weight used and assign to the height
            //and weight varriable
            weight = double.Parse(weightTextBox.Text);
            height = double.Parse(heightTextBox.Text);

            //calculate BMI
            BMI = weight * 703 / (height * height);

            //Display answer in BMI lable
            bmiTextBox.Text = BMI.ToString();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }
    }
}
