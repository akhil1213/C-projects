﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rock_Paper_Scissor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int compChoice;
        private void StartButton_Click(object sender, EventArgs e)
        {
            //Make the program choice a number between 1 and 3
            // when the user clicks the start button
            Random rand = new Random();
            compChoice = rand.Next(1, 4);
            
        }
        // Make the button for Rock display results of the game
        private void RockButton_Click(object sender, EventArgs e)
        {

            if (compChoice == 1) {
                displayLabel.Text = "Tie!";
            }else if (compChoice == 2)
            {
                displayLabel.Text = "You win!";
            }
            else
            {
                displayLabel.Text = "You Lose!";
            }
        }
        // Make the button for Scissor display results of the game
        private void ScissorButton_Click(object sender, EventArgs e)
        {
            if (compChoice == 1)
            {
                displayLabel.Text = "You Lose!";
            }
            else if (compChoice == 2)
            {
                displayLabel.Text = "Tie!";
            }
            else
            {
                displayLabel.Text = "You Win!";
            }
        }
            // Make the button for Paper display results of the game
        private void PaperButton_Click(object sender, EventArgs e)
        {
            if (compChoice == 1)
            {
                displayLabel.Text = "You Win!";
            }
            else if (compChoice == 2)
            {
                displayLabel.Text = "You Lose!";
            }
            else
            {
                displayLabel.Text = "Tie!";
            }
        }
    }
}
