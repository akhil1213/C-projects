﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Random_Number_Guessing_Game
{
    
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        bool correct = true;
        private void GuessNumberButton_Click(object sender, EventArgs e)
        {
            //Variable to indicate your guess
            int guess = Int32.Parse(guessNumberTextbox.Text);
            if (correct == true)
            {
                int random = getRandom();
            }

            // Generate random number

            if (guess == Random) 
            { //display Congradulation your correct
                displayLabel.Text = "Congrats your a Winner!!";
                correct = true;
            }
            if (guess < Random) 
            { //display guess too low
                displayLabel.Text = "Too Low, Try Again" ;
                correct = false;
            }
            if (guess > Random) 
            { //display guess too high
                displayLabel.Text = "Too High, Try Again" ;
                correct = false;
            }            
        }
        private int getRandom()
        {
            //Create a Random New object
            Random rand = new Random();

            //Get a random integter from 1 to 100
            int random = rand.Next(1, 100);
            return random;
        }
        private void ExitButton_Click(object sender, EventArgs e)
        {
            //close the appllication
            this.Close(); 
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
