﻿namespace Random_Number_Guessing_Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guessNumberButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.guessNumberTextbox = new System.Windows.Forms.TextBox();
            this.guessNumberLabel = new System.Windows.Forms.Label();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.displayLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // guessNumberButton
            // 
            this.guessNumberButton.Location = new System.Drawing.Point(162, 334);
            this.guessNumberButton.Name = "guessNumberButton";
            this.guessNumberButton.Size = new System.Drawing.Size(159, 61);
            this.guessNumberButton.TabIndex = 0;
            this.guessNumberButton.Text = "Guess your number";
            this.guessNumberButton.UseVisualStyleBackColor = true;
            this.guessNumberButton.Click += new System.EventHandler(this.GuessNumberButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(412, 334);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(159, 61);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // guessNumberTextbox
            // 
            this.guessNumberTextbox.Location = new System.Drawing.Point(432, 191);
            this.guessNumberTextbox.Name = "guessNumberTextbox";
            this.guessNumberTextbox.Size = new System.Drawing.Size(159, 31);
            this.guessNumberTextbox.TabIndex = 2;
            // 
            // guessNumberLabel
            // 
            this.guessNumberLabel.Location = new System.Drawing.Point(129, 191);
            this.guessNumberLabel.Name = "guessNumberLabel";
            this.guessNumberLabel.Size = new System.Drawing.Size(192, 31);
            this.guessNumberLabel.TabIndex = 3;
            this.guessNumberLabel.Text = "Enter your guess ";
            this.guessNumberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // instructionLabel
            // 
            this.instructionLabel.Location = new System.Drawing.Point(157, 48);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(414, 99);
            this.instructionLabel.TabIndex = 4;
            this.instructionLabel.Text = "Your job in this application is to guess a number between 1-100. Keep guessing un" +
    "til you win to reveal your suprise! ";
            this.instructionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // displayLabel
            // 
            this.displayLabel.Location = new System.Drawing.Point(187, 276);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(339, 25);
            this.displayLabel.TabIndex = 5;
            this.displayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(725, 470);
            this.Controls.Add(this.displayLabel);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.guessNumberLabel);
            this.Controls.Add(this.guessNumberTextbox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.guessNumberButton);
            this.Name = "Form1";
            this.Text = "Random Number Guessing Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button guessNumberButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox guessNumberTextbox;
        private System.Windows.Forms.Label guessNumberLabel;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Label displayLabel;
    }
}

