﻿namespace Driver_s_License_Exam
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.displayLabel = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(36, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(496, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "1. If you plan to pass another vehicle, you should: ";
            this.label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(58, 40);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(716, 31);
            this.label2.TabIndex = 1;
            this.label2.Text = "A. Assume the other driver will let you pass if you use your turn signal. ";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(56, 71);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(758, 31);
            this.label3.TabIndex = 2;
            this.label3.Text = "B. Not assume the other driver will make space for you to return to your lane. ";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(56, 102);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(396, 31);
            this.label4.TabIndex = 3;
            this.label4.Text = "C. Assume the other driver will maintain a constant speed.";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(36, 152);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(868, 31);
            this.label5.TabIndex = 4;
            this.label5.Text = "2. A solid white line on the right edge of the highway slants in to the left. Tha" +
    "t shows that: ";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(58, 183);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(396, 31);
            this.label6.TabIndex = 5;
            this.label6.Text = "A. There is an intersection just ahead. ";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(58, 214);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(520, 31);
            this.label7.TabIndex = 6;
            this.label7.Text = "B. You are approaching a construction area. ";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(56, 245);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(584, 31);
            this.label8.TabIndex = 7;
            this.label8.Text = "C. You will be required to turn left just ahead. ";
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(58, 276);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(396, 31);
            this.label9.TabIndex = 8;
            this.label9.Text = "D. The road will get narrower. ";
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(36, 325);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(396, 31);
            this.label10.TabIndex = 9;
            this.label10.Text = "3. When changing lanes, you should: ";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(56, 356);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(396, 31);
            this.label11.TabIndex = 10;
            this.label11.Text = "A. Always check your blind spot. ";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(58, 387);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(844, 31);
            this.label12.TabIndex = 11;
            this.label12.Text = "B. Signal at least 500 feet before your lane change when driving on residential s" +
    "treets. ";
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(58, 418);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(536, 31);
            this.label13.TabIndex = 12;
            this.label13.Text = "C. Begin signaling as you move into the next lane. ";
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(58, 449);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(396, 31);
            this.label14.TabIndex = 13;
            this.label14.Text = "D. Rely on your mirrors. ";
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(36, 495);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(756, 31);
            this.label15.TabIndex = 14;
            this.label15.Text = "4.The best way to avoid hydroplaning is to: ";
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(56, 526);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(396, 31);
            this.label16.TabIndex = 15;
            this.label16.Text = "A. All of the above. ";
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(58, 557);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(452, 31);
            this.label17.TabIndex = 16;
            this.label17.Text = "B. Watch out for standing water or puddles. ";
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(58, 588);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(474, 31);
            this.label18.TabIndex = 17;
            this.label18.Text = "C. Slow down when roads are wet or slushy. ";
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(58, 619);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(396, 31);
            this.label19.TabIndex = 18;
            this.label19.Text = "D. Keep your tires properly maintained. ";
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(36, 675);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(756, 31);
            this.label20.TabIndex = 19;
            this.label20.Text = "5. Minimum speed signs are designed to: ";
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(58, 706);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(756, 31);
            this.label21.TabIndex = 20;
            this.label21.Text = "A. Show current local road conditions. ";
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(58, 737);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(756, 31);
            this.label22.TabIndex = 21;
            this.label22.Text = "B. Test future traffic signal needs. ";
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(58, 768);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(756, 31);
            this.label23.TabIndex = 22;
            this.label23.Text = "C. Keep traffic flowing smoothly. ";
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(56, 799);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(756, 31);
            this.label24.TabIndex = 23;
            this.label24.Text = "D. Ensure pedestrian safety. ";
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(36, 843);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(756, 31);
            this.label25.TabIndex = 24;
            this.label25.Text = "6. A five-ounce glass of wine contains the same amount of alcohol as: ";
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(56, 874);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(756, 31);
            this.label26.TabIndex = 25;
            this.label26.Text = "A. One 12-ounce can of beer. ";
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(56, 905);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(756, 31);
            this.label27.TabIndex = 26;
            this.label27.Text = "B. One pint of whiskey. ";
            // 
            // label28
            // 
            this.label28.Location = new System.Drawing.Point(56, 936);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(756, 31);
            this.label28.TabIndex = 27;
            this.label28.Text = "C. A gallon of wine. ";
            // 
            // label29
            // 
            this.label29.Location = new System.Drawing.Point(56, 967);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(756, 31);
            this.label29.TabIndex = 28;
            this.label29.Text = "D. six-pack of beer. ";
            // 
            // label30
            // 
            this.label30.Location = new System.Drawing.Point(36, 1008);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(756, 31);
            this.label30.TabIndex = 29;
            this.label30.Text = "7.If you see an edge line that angles inward on a road, it means: ";
            // 
            // label31
            // 
            this.label31.Location = new System.Drawing.Point(58, 1070);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(756, 31);
            this.label31.TabIndex = 30;
            this.label31.Text = "B. The road is narrowing. ";
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(56, 1039);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(756, 31);
            this.label32.TabIndex = 31;
            this.label32.Text = "A. The road is getting wider. ";
            // 
            // label33
            // 
            this.label33.Location = new System.Drawing.Point(58, 1101);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(756, 31);
            this.label33.TabIndex = 32;
            this.label33.Text = "C. The speed limit is increasing.";
            // 
            // label34
            // 
            this.label34.Location = new System.Drawing.Point(58, 1132);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(756, 31);
            this.label34.TabIndex = 33;
            this.label34.Text = "D. The speed limit is decreasing.";
            // 
            // label35
            // 
            this.label35.Location = new System.Drawing.Point(36, 1163);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(756, 62);
            this.label35.TabIndex = 34;
            this.label35.Text = "8. You want to back out of your driveway. You see children playing nearby. Before" +
    " you start to move your car, you should: ";
            // 
            // label36
            // 
            this.label36.Location = new System.Drawing.Point(58, 1225);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(756, 31);
            this.label36.TabIndex = 35;
            this.label36.Text = "A. Walk to the back of the car to be sure the way is clear. ";
            // 
            // label37
            // 
            this.label37.Location = new System.Drawing.Point(58, 1255);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(756, 31);
            this.label37.TabIndex = 36;
            this.label37.Text = "B. Rev your engine to warn the children that you are moving. ";
            // 
            // label38
            // 
            this.label38.Location = new System.Drawing.Point(56, 1286);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(756, 31);
            this.label38.TabIndex = 37;
            this.label38.Text = "C. Sound your horn so the children will hear you. ";
            this.label38.Click += new System.EventHandler(this.Label38_Click);
            // 
            // label39
            // 
            this.label39.Location = new System.Drawing.Point(56, 1317);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(756, 31);
            this.label39.TabIndex = 38;
            this.label39.Text = "D. Tell the children to stay away from the driveway. ";
            // 
            // label40
            // 
            this.label40.Location = new System.Drawing.Point(36, 1348);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(756, 31);
            this.label40.TabIndex = 39;
            this.label40.Text = "9. Vehicle stopping distances never depend on: ";
            // 
            // label41
            // 
            this.label41.Location = new System.Drawing.Point(58, 1379);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(756, 31);
            this.label41.TabIndex = 40;
            this.label41.Text = "A. Your own reaction time. ";
            this.label41.Click += new System.EventHandler(this.Label41_Click);
            // 
            // label42
            // 
            this.label42.Location = new System.Drawing.Point(58, 1410);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(756, 31);
            this.label42.TabIndex = 41;
            this.label42.Text = "B. The condition of your vehicle\'s brakes. ";
            // 
            // label43
            // 
            this.label43.Location = new System.Drawing.Point(58, 1441);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(756, 31);
            this.label43.TabIndex = 42;
            this.label43.Text = "C. The time of day. ";
            // 
            // label44
            // 
            this.label44.Location = new System.Drawing.Point(58, 1473);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(756, 31);
            this.label44.TabIndex = 43;
            this.label44.Text = "D. The condition and type of your vehicle\'s tires. ";
            // 
            // label45
            // 
            this.label45.Location = new System.Drawing.Point(36, 1501);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(738, 51);
            this.label45.TabIndex = 44;
            this.label45.Text = "10. On a New York State highway where there is no posted speed limit, the fastest" +
    " you may legally drive is: ";
            // 
            // label46
            // 
            this.label46.Location = new System.Drawing.Point(56, 1552);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(756, 31);
            this.label46.TabIndex = 45;
            this.label46.Text = "A. 65 mph.";
            // 
            // label47
            // 
            this.label47.Location = new System.Drawing.Point(56, 1583);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(756, 31);
            this.label47.TabIndex = 46;
            this.label47.Text = "B. 60 mph.";
            // 
            // label48
            // 
            this.label48.Location = new System.Drawing.Point(58, 1614);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(756, 31);
            this.label48.TabIndex = 47;
            this.label48.Text = "C. 50 mph.";
            // 
            // label49
            // 
            this.label49.Location = new System.Drawing.Point(58, 1641);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(756, 31);
            this.label49.TabIndex = 48;
            this.label49.Text = "D. 55 mph. ";
            // 
            // label50
            // 
            this.label50.Location = new System.Drawing.Point(973, -3);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(756, 31);
            this.label50.TabIndex = 49;
            this.label50.Text = "11. What kinds of drugs can affect your driving ability? ";
            // 
            // label51
            // 
            this.label51.Location = new System.Drawing.Point(995, 28);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(756, 31);
            this.label51.TabIndex = 50;
            this.label51.Text = "A. Allergy medicine ";
            // 
            // label52
            // 
            this.label52.Location = new System.Drawing.Point(995, 59);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(756, 31);
            this.label52.TabIndex = 51;
            this.label52.Text = "B. All of the above.";
            // 
            // label53
            // 
            this.label53.Location = new System.Drawing.Point(995, 90);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(756, 31);
            this.label53.TabIndex = 52;
            this.label53.Text = "C. Marijuana ";
            // 
            // label54
            // 
            this.label54.Location = new System.Drawing.Point(995, 121);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(756, 31);
            this.label54.TabIndex = 53;
            this.label54.Text = "D. Cold remedies.";
            // 
            // label55
            // 
            this.label55.Location = new System.Drawing.Point(973, 152);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(756, 62);
            this.label55.TabIndex = 54;
            this.label55.Text = "12. Assuming that the street is level, what should you do after you have finished" +
    " parallel parking in a space between two other cars? ";
            // 
            // label56
            // 
            this.label56.Location = new System.Drawing.Point(995, 204);
            this.label56.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(756, 31);
            this.label56.TabIndex = 55;
            this.label56.Text = "A. Leave your front wheels turned toward the curb. ";
            // 
            // label57
            // 
            this.label57.Location = new System.Drawing.Point(995, 235);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(756, 31);
            this.label57.TabIndex = 56;
            this.label57.Text = "B. Make sure your car almost touches the car behind you. ";
            // 
            // label58
            // 
            this.label58.Location = new System.Drawing.Point(995, 266);
            this.label58.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(756, 31);
            this.label58.TabIndex = 57;
            this.label58.Text = "C. Straighten your front wheels and leave room between cars. ";
            // 
            // label59
            // 
            this.label59.Location = new System.Drawing.Point(995, 297);
            this.label59.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(756, 31);
            this.label59.TabIndex = 58;
            this.label59.Text = "D. Move as far forward in the space as possible. ";
            // 
            // label60
            // 
            this.label60.Location = new System.Drawing.Point(973, 339);
            this.label60.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(756, 31);
            this.label60.TabIndex = 59;
            this.label60.Text = "13. In the state of New York, ____ must wear seat belts in moving vehicles. ";
            // 
            // label61
            // 
            this.label61.Location = new System.Drawing.Point(995, 370);
            this.label61.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(756, 31);
            this.label61.TabIndex = 60;
            this.label61.Text = "A. Only passengers ";
            this.label61.Click += new System.EventHandler(this.Label61_Click);
            // 
            // label62
            // 
            this.label62.Location = new System.Drawing.Point(995, 401);
            this.label62.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(756, 31);
            this.label62.TabIndex = 61;
            this.label62.Text = "B. Only drivers ";
            // 
            // label63
            // 
            this.label63.Location = new System.Drawing.Point(995, 432);
            this.label63.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(756, 31);
            this.label63.TabIndex = 62;
            this.label63.Text = "C. Only children ";
            // 
            // label64
            // 
            this.label64.Location = new System.Drawing.Point(995, 463);
            this.label64.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(756, 31);
            this.label64.TabIndex = 63;
            this.label64.Text = "D. Drivers and all passengers ";
            // 
            // label65
            // 
            this.label65.Location = new System.Drawing.Point(973, 509);
            this.label65.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(756, 31);
            this.label65.TabIndex = 64;
            this.label65.Text = "14. Blind spots are: ";
            // 
            // label66
            // 
            this.label66.Location = new System.Drawing.Point(995, 540);
            this.label66.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(756, 31);
            this.label66.TabIndex = 65;
            this.label66.Text = "A. Areas of the road that cannot be seen in a vehicle\'s mirrors. ";
            // 
            // label67
            // 
            this.label67.Location = new System.Drawing.Point(995, 571);
            this.label67.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(756, 31);
            this.label67.TabIndex = 66;
            this.label67.Text = "B. Spots in your vision when you become fatigued. ";
            // 
            // label68
            // 
            this.label68.Location = new System.Drawing.Point(995, 602);
            this.label68.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(756, 31);
            this.label68.TabIndex = 67;
            this.label68.Text = "C. Traffic control devices. ";
            // 
            // label69
            // 
            this.label69.Location = new System.Drawing.Point(973, 643);
            this.label69.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(756, 31);
            this.label69.TabIndex = 68;
            this.label69.Text = "15. Blind persons legally have the right-of-way when crossing the street when the" +
    "y are: ";
            // 
            // label70
            // 
            this.label70.Location = new System.Drawing.Point(995, 675);
            this.label70.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(756, 31);
            this.label70.TabIndex = 69;
            this.label70.Text = "A. Wearing light-colored clothing. ";
            // 
            // label71
            // 
            this.label71.Location = new System.Drawing.Point(995, 706);
            this.label71.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(756, 31);
            this.label71.TabIndex = 70;
            this.label71.Text = "B. Wearing dark-colored glasses. ";
            // 
            // label72
            // 
            this.label72.Location = new System.Drawing.Point(995, 737);
            this.label72.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(756, 31);
            this.label72.TabIndex = 71;
            this.label72.Text = "C. Helped by another person. ";
            // 
            // label73
            // 
            this.label73.Location = new System.Drawing.Point(995, 768);
            this.label73.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(756, 31);
            this.label73.TabIndex = 72;
            this.label73.Text = "D. Led by a guide dog or using a white or metallic cane. ";
            // 
            // label74
            // 
            this.label74.Location = new System.Drawing.Point(973, 810);
            this.label74.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(756, 31);
            this.label74.TabIndex = 73;
            this.label74.Text = "16. To improve visibility lowered by rain or fog, drivers should use their: ";
            // 
            // label75
            // 
            this.label75.Location = new System.Drawing.Point(995, 841);
            this.label75.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(756, 31);
            this.label75.TabIndex = 74;
            this.label75.Text = "A. Parking lights. ";
            // 
            // label76
            // 
            this.label76.Location = new System.Drawing.Point(995, 874);
            this.label76.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(756, 31);
            this.label76.TabIndex = 75;
            this.label76.Text = "B. High beam headlights. ";
            // 
            // label77
            // 
            this.label77.Location = new System.Drawing.Point(995, 905);
            this.label77.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(756, 31);
            this.label77.TabIndex = 76;
            this.label77.Text = "C. Low beam headlights. ";
            // 
            // label78
            // 
            this.label78.Location = new System.Drawing.Point(973, 948);
            this.label78.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(756, 31);
            this.label78.TabIndex = 77;
            this.label78.Text = "17. Allow extra space in front of your vehicle when following a: ";
            // 
            // label79
            // 
            this.label79.Location = new System.Drawing.Point(995, 979);
            this.label79.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(756, 31);
            this.label79.TabIndex = 78;
            this.label79.Text = "A. Station wagon. ";
            // 
            // label80
            // 
            this.label80.Location = new System.Drawing.Point(995, 1010);
            this.label80.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(756, 31);
            this.label80.TabIndex = 79;
            this.label80.Text = "B. Passenger vehicle. ";
            // 
            // label81
            // 
            this.label81.Location = new System.Drawing.Point(995, 1041);
            this.label81.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(756, 31);
            this.label81.TabIndex = 80;
            this.label81.Text = "C. Motorcycle. ";
            // 
            // label82
            // 
            this.label82.Location = new System.Drawing.Point(973, 1083);
            this.label82.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(756, 31);
            this.label82.TabIndex = 82;
            this.label82.Text = "18. The car behind you begins to pass you. You should: ";
            // 
            // label83
            // 
            this.label83.Location = new System.Drawing.Point(995, 1114);
            this.label83.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(756, 31);
            this.label83.TabIndex = 83;
            this.label83.Text = "A. Maintain your speed so traffic will flow smoothly. ";
            // 
            // label84
            // 
            this.label84.Location = new System.Drawing.Point(995, 1145);
            this.label84.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(756, 31);
            this.label84.TabIndex = 84;
            this.label84.Text = "B. Slow down slightly and stay in your lane. ";
            // 
            // label85
            // 
            this.label85.Location = new System.Drawing.Point(995, 1177);
            this.label85.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(756, 31);
            this.label85.TabIndex = 85;
            this.label85.Text = "C. Blow your horn to signal that it to pass. ";
            // 
            // label86
            // 
            this.label86.Location = new System.Drawing.Point(995, 1208);
            this.label86.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(756, 31);
            this.label86.TabIndex = 86;
            this.label86.Text = "D. Pull to the right and stop so it can pass. ";
            // 
            // label87
            // 
            this.label87.Location = new System.Drawing.Point(973, 1255);
            this.label87.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(756, 31);
            this.label87.TabIndex = 87;
            this.label87.Text = "19. People driving under theinfluence of alcohol are: ";
            // 
            // label88
            // 
            this.label88.Location = new System.Drawing.Point(995, 1286);
            this.label88.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(756, 31);
            this.label88.TabIndex = 88;
            this.label88.Text = "A. Not a problem in New York State. ";
            // 
            // label89
            // 
            this.label89.Location = new System.Drawing.Point(995, 1317);
            this.label89.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(756, 31);
            this.label89.TabIndex = 89;
            this.label89.Text = "B. A police enforcement problem only. ";
            // 
            // label90
            // 
            this.label90.Location = new System.Drawing.Point(995, 1348);
            this.label90.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(756, 31);
            this.label90.TabIndex = 90;
            this.label90.Text = "C. Only a problem to those who drink. ";
            // 
            // label91
            // 
            this.label91.Location = new System.Drawing.Point(995, 1379);
            this.label91.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(756, 31);
            this.label91.TabIndex = 91;
            this.label91.Text = "D. Every driver\'s problem. ";
            // 
            // label92
            // 
            this.label92.Location = new System.Drawing.Point(973, 1423);
            this.label92.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(756, 64);
            this.label92.TabIndex = 92;
            this.label92.Text = "20. A fully loaded tractor-trailer traveling at 55 mph could take up to ____ to c" +
    "ome to a complete stop. ";
            // 
            // label93
            // 
            this.label93.Location = new System.Drawing.Point(995, 1470);
            this.label93.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(756, 31);
            this.label93.TabIndex = 93;
            this.label93.Text = "A. 400 feet.";
            // 
            // label94
            // 
            this.label94.Location = new System.Drawing.Point(995, 1501);
            this.label94.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(756, 31);
            this.label94.TabIndex = 94;
            this.label94.Text = "B. 50 feet.";
            // 
            // label95
            // 
            this.label95.Location = new System.Drawing.Point(995, 1532);
            this.label95.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(756, 31);
            this.label95.TabIndex = 95;
            this.label95.Text = "C. 125 feet.";
            // 
            // label96
            // 
            this.label96.Location = new System.Drawing.Point(995, 1562);
            this.label96.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(756, 31);
            this.label96.TabIndex = 96;
            this.label96.Text = "D. 700 feet.";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(856, 40);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 31);
            this.textBox1.TabIndex = 97;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(856, 183);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 31);
            this.textBox2.TabIndex = 98;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(856, 356);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 31);
            this.textBox3.TabIndex = 99;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(856, 526);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 31);
            this.textBox4.TabIndex = 100;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(856, 689);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 31);
            this.textBox5.TabIndex = 101;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(856, 874);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 31);
            this.textBox6.TabIndex = 102;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(856, 1039);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 31);
            this.textBox7.TabIndex = 103;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(856, 1237);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 31);
            this.textBox8.TabIndex = 104;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(856, 1408);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 31);
            this.textBox9.TabIndex = 105;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(856, 1552);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 31);
            this.textBox10.TabIndex = 106;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(1720, 28);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 31);
            this.textBox11.TabIndex = 107;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(1720, 204);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 31);
            this.textBox12.TabIndex = 108;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(1720, 370);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 31);
            this.textBox13.TabIndex = 109;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(1720, 540);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 31);
            this.textBox14.TabIndex = 110;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(1720, 677);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 31);
            this.textBox15.TabIndex = 111;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(1720, 844);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 31);
            this.textBox16.TabIndex = 112;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(1720, 967);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(100, 31);
            this.textBox17.TabIndex = 113;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(1720, 1114);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(100, 31);
            this.textBox18.TabIndex = 114;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(1720, 1283);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(100, 31);
            this.textBox19.TabIndex = 115;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(1720, 1470);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 31);
            this.textBox20.TabIndex = 116;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(1510, 1587);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(157, 58);
            this.submitButton.TabIndex = 117;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // displayLabel
            // 
            this.displayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayLabel.Location = new System.Drawing.Point(1317, 1517);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(522, 48);
            this.displayLabel.TabIndex = 118;
            this.displayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label97
            // 
            this.label97.Location = new System.Drawing.Point(1179, 1490);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(304, 62);
            this.label97.TabIndex = 119;
            this.label97.Text = "Enter your answers below 1-20 sperated by a comma.";
            this.label97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(1183, 1596);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(300, 31);
            this.textBox21.TabIndex = 120;
            this.textBox21.TextChanged += new System.EventHandler(this.TextBox21_TextChanged);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(1691, 1587);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(157, 58);
            this.exitButton.TabIndex = 121;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1832, 1783);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.label97);
            this.Controls.Add(this.displayLabel);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label96);
            this.Controls.Add(this.label95);
            this.Controls.Add(this.label94);
            this.Controls.Add(this.label93);
            this.Controls.Add(this.label92);
            this.Controls.Add(this.label91);
            this.Controls.Add(this.label90);
            this.Controls.Add(this.label89);
            this.Controls.Add(this.label88);
            this.Controls.Add(this.label87);
            this.Controls.Add(this.label86);
            this.Controls.Add(this.label85);
            this.Controls.Add(this.label84);
            this.Controls.Add(this.label83);
            this.Controls.Add(this.label82);
            this.Controls.Add(this.label81);
            this.Controls.Add(this.label80);
            this.Controls.Add(this.label79);
            this.Controls.Add(this.label78);
            this.Controls.Add(this.label77);
            this.Controls.Add(this.label76);
            this.Controls.Add(this.label75);
            this.Controls.Add(this.label74);
            this.Controls.Add(this.label73);
            this.Controls.Add(this.label72);
            this.Controls.Add(this.label71);
            this.Controls.Add(this.label70);
            this.Controls.Add(this.label69);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.label57);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Driver License Exam";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Label displayLabel;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Button exitButton;
    }
}

