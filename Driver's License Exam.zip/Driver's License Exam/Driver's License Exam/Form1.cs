﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Driver_s_License_Exam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            char[] arr = { 'A', 'C', 'B', 'D', };
            
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label38_Click(object sender, EventArgs e)
        {

        }

        private void Label41_Click(object sender, EventArgs e)
        {

        }

        private void Label61_Click(object sender, EventArgs e)
        {

        }

        private void TextBox21_TextChanged(object sender, EventArgs e)
        {

        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            string[] answers = { "B", "D", "A", "A", "C", "A",
                "B", "A", "C", "D", "B", "C", "D", "A", "D", "C", "C", "B", "D", "A" };
            string usersAnswer = textBox21.Text;
            string[] usersAnswersArray = usersAnswer.Split(',');
            int grade = 0;
            for(int i = 0; i < usersAnswersArray.Length; i++)
            {
                if (answers[i].Equals(usersAnswersArray[i].ToUpper()))
                {
                    grade = grade + 5;
                }
            }
            if (grade > 65)
            {
                displayLabel.Text = "You passed, ";
            }
            else
            {
                displayLabel.Text = "You failed, ";
            }
            displayLabel.Text += "Grade:" + grade +"%";
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close(); 

        }
    }
}
