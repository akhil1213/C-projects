﻿namespace Hospital_Charges_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.displayLabel = new System.Windows.Forms.Label();
            this.daysTextbox = new System.Windows.Forms.TextBox();
            this.medicationTextbox = new System.Windows.Forms.TextBox();
            this.surgicalTextbox = new System.Windows.Forms.TextBox();
            this.labTextBox = new System.Windows.Forms.TextBox();
            this.rehabilitationTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(65, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(420, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "The number of days spent in the hospital";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(65, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(420, 31);
            this.label2.TabIndex = 1;
            this.label2.Text = "The amount of medication charges";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(65, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(420, 31);
            this.label3.TabIndex = 2;
            this.label3.Text = "The amount of surgical charges";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(65, 229);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(420, 31);
            this.label4.TabIndex = 3;
            this.label4.Text = "The amount of lab fees";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(65, 280);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(420, 31);
            this.label5.TabIndex = 4;
            this.label5.Text = "The amount of physical rehabilitation charges";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(114, 392);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(188, 73);
            this.calculateButton.TabIndex = 5;
            this.calculateButton.Text = "Calculate Total Charges ";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(387, 392);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(188, 73);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // displayLabel
            // 
            this.displayLabel.Location = new System.Drawing.Point(264, 337);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(384, 31);
            this.displayLabel.TabIndex = 7;
            // 
            // daysTextbox
            // 
            this.daysTextbox.Location = new System.Drawing.Point(523, 66);
            this.daysTextbox.Name = "daysTextbox";
            this.daysTextbox.Size = new System.Drawing.Size(100, 31);
            this.daysTextbox.TabIndex = 8;
            // 
            // medicationTextbox
            // 
            this.medicationTextbox.Location = new System.Drawing.Point(523, 117);
            this.medicationTextbox.Name = "medicationTextbox";
            this.medicationTextbox.Size = new System.Drawing.Size(100, 31);
            this.medicationTextbox.TabIndex = 9;
            // 
            // surgicalTextbox
            // 
            this.surgicalTextbox.Location = new System.Drawing.Point(523, 177);
            this.surgicalTextbox.Name = "surgicalTextbox";
            this.surgicalTextbox.Size = new System.Drawing.Size(100, 31);
            this.surgicalTextbox.TabIndex = 10;
            // 
            // labTextBox
            // 
            this.labTextBox.Location = new System.Drawing.Point(523, 229);
            this.labTextBox.Name = "labTextBox";
            this.labTextBox.Size = new System.Drawing.Size(100, 31);
            this.labTextBox.TabIndex = 11;
            // 
            // rehabilitationTextBox
            // 
            this.rehabilitationTextBox.Location = new System.Drawing.Point(523, 280);
            this.rehabilitationTextBox.Name = "rehabilitationTextBox";
            this.rehabilitationTextBox.Size = new System.Drawing.Size(100, 31);
            this.rehabilitationTextBox.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 25);
            this.label6.TabIndex = 13;
            this.label6.Text = "label6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(188, 320);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 25);
            this.label7.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(757, 491);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.rehabilitationTextBox);
            this.Controls.Add(this.labTextBox);
            this.Controls.Add(this.surgicalTextbox);
            this.Controls.Add(this.medicationTextbox);
            this.Controls.Add(this.daysTextbox);
            this.Controls.Add(this.displayLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label displayLabel;
        private System.Windows.Forms.TextBox daysTextbox;
        private System.Windows.Forms.TextBox medicationTextbox;
        private System.Windows.Forms.TextBox surgicalTextbox;
        private System.Windows.Forms.TextBox labTextBox;
        private System.Windows.Forms.TextBox rehabilitationTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}

