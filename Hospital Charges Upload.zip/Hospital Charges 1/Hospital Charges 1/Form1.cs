﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Charges_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            //Declare all the charges and total balance as variables
            int hospital = Int32.Parse(daysTextbox.Text) ;
            int medication = Int32.Parse(medicationTextbox.Text);
            int surgical = Int32.Parse(surgicalTextbox.Text);
            int lab = Int32.Parse(labTextBox.Text);
            int rehabilitation = Int32.Parse(rehabilitationTextBox.Text);
            int count = 1;
            // Set interger stayCharge 
            int stayCharge = calcStayCharges(hospital);
            displayLabel.Text = "" + calcTotalCharges(calcStayCharges(hospital), 
                calcMiscCharges(medication, surgical, lab, rehabilitation));
            //Get the numnber of days
            
        }
         int calcStayCharges(int hospital)
        {
            return 350 * hospital;
        }
         int calcMiscCharges(int medication, int surgical, int lab, int rehabilitation)
        {
            return medication + surgical + lab + rehabilitation;

        }
         int calcTotalCharges(int staycharge, int miscCharge)
        {
            return staycharge + miscCharge;
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }
    }
}
