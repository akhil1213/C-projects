﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlphabeticTelephoneNumberTranslator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            string answer = input.Substring(0, 3);
            answer += "-";
            char [] inputarr = input.ToCharArray();
            for( int i = 3; i < input.Length; i++)
            {
                char c = inputarr[i];
                int numberToAddToAnswer;
                switch (c)
                {
                    case 'A': case 'B': case 'C': answer += "2"; break;
                    case 'D': case 'E': case 'F': answer += "3"; break;
                    case 'G': case 'H': case 'I': answer += "4"; break;
                    case 'J': case 'K': case 'L': answer += "5"; break;
                    case 'M': case 'N': case 'O': answer += "6"; break;
                    case 'P': case 'Q': case 'R': answer += "7"; break;
                    case 'T': case 'U': case 'V': answer += "8"; break;
                    case 'W': case 'X': case 'Y': case 'Z': answer += "9"; break;

                }
            }
            label1.Text = answer;
        }
    }
}
