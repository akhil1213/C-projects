﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Magic_Datees
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            double Day;  // To hold the day of the month
            double Month; // To hold the month
            double Year; // To hold the year

            //Get the day, month and year and assign it to the 
            // day, month and year variables
            Day = double.Parse(dayTextBox.Text);
            Month = double.Parse(monthTextBox.Text);
            Year = double.Parse(yearTextBox.Text);

            //Determine if the day times the month equals the year
            if (Day * Month == Year)//two equals because ur trying to 
                                    //compare the value of day*month and year
            {
                displayLabel.Text = "THE DATE IS MAGIC!";
            }

            else
            {
                displayLabel.Text = "ITS NOT MAGIC BRUH :(";
            }

        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }
    }
}
