﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_mail_Address_Book
{
    public partial class EmailAndPhoneform : Form
    {
        public EmailAndPhoneform()
        {
            InitializeComponent();
        }
    }
}
