﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_mail_Address_Book.Properties
{
    class PersonEntry
    {
        string name, email, phone;
        public PersonEntry(string x, string e, string p)
        {
            name = x;
            email = e;
            phone = p;
        }
        public string get()
        {
            return name;
        }
        
        
    }
}
