﻿namespace E_mail_Address_Book
{
    internal class PersonEntry
    {
    }
}