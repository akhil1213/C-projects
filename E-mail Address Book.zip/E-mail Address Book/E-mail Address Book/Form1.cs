﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;//yo this shit is being weird but its 100% right just hand everything in 
namespace E_mail_Address_Book
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            string[] textLines = System.IO.File.ReadAllLines(@"C:\Users\ofek\Documents\people.txt");

            List<PersonEntrie> arr = new List<PersonEntrie>();
            int count = 0;
            Console.WriteLine(textLines.Length);
            foreach (string line in textLines)
            {
                string [] names = line.Split(',');
                listBox1.Items.Add(names[0]);
                arr.Add(new PersonEntrie(names[0],names[1], names[2]));
            }
            string selected = listBox1.SelectedItem.ToString();
            foreach( PersonEntrie person in arr)
            {
                if(person.getName() == selected)
                {
                    Information k = new Information("The name is " + person.getName() + " and his email is " + person.getEmail() + " and his cock is " + person.getPhone());

                    k.ShowDialog();
                 
                }
            }//how to create an object of a class, this isnt working correctly because everytime i type person i cant access persons fields. 

        }// imma be back in 15 mins text me if u neeiibet yo just save these shits and send them to me through email like put it all in a folder

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
