﻿namespace E_mail_Address_Book
{
    internal class PersonEntrie
    {
        string name, email, phone;
        public PersonEntrie(string x, string e, string p)
        {
            name = x;
            email = e;
            phone = p;
        }
        public string getName()
        {
            return name;
        }
        public string getEmail()
        {
            return email;
        }
        public string getPhone()
        {
            return phone;
        }
        

    }
}